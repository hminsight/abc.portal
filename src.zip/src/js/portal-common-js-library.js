if (typeof portal_common === "undefined") {
  portal_common = { _namespace: true };
}

portal_common = {

  getUrlParameter: function (sParam) {
    var url = new URLSearchParams(window.location.search);
    return url.get(sParam);
  },

  cleanupEscapeText: function (text) {
    return text
      .replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace("&#39;", "'");
  },

  // Validation summary for Enhanced Data Model
  runPlatformValidation: function() {
    var valid = true;
    if (typeof window.Page_ClientValidate === "function") {
      window.Page_ClientValidate();                 // computes Page_IsValid
      valid = (window.Page_IsValid === true);
    } else if (typeof window.entityFormClientValidate === "function") {
      valid = !!window.entityFormClientValidate();  // OOB summary shown when false
    }

    return valid;
  },

  getFirstValidationSummary: function() {
    // Try common containers
    var $summary =
      $("#ValidationSummaryEntityFormControl_EntityFormView")
        .add("#ValidationSummaryBasicForm")
        .add($("[id^='ValidationSummary']"))
        .add($(".validation-summary"));

    if ($summary.length) {
      $summary.first().show();
      return $summary.first();
    }
  },

  getAllValidationSummaries: function() {
    // Try common containers
    var $summary =
      $("#ValidationSummaryEntityFormControl_EntityFormView")
        .add("#ValidationSummaryBasicForm")
        .add($("[id^='ValidationSummary']"))
        .add($(".validation-summary"));

    if ($summary.length) {
      $summary.first().show();
      return $summary;
    }
  },

  focusValidationSummary: function($summary) {
    var top = $summary.offset() ? ($summary.offset().top - 100) : 0;
    $("html, body").animate({ scrollTop: top }, 300);
  },

  collectFormData: function(submitRecord, submittedStatusReasonValue) {
    let data = {};

    // Select the fieldset where all fields are in the basic form
    let fieldSets = document.querySelectorAll('fieldset');

    // Loop through all fieldsets present in the basic form
    fieldSets.forEach(function(fieldSet) {

      // Select all fields inside the basic form
      let formElements = fieldSet.querySelectorAll("form input, form select, form textarea");
      formElements.forEach(function(el) {

        // Skip elements without a name or id (Dataverse needs logical names) or hidden fields
        let fieldname = el.getAttribute("id");
        let classname = el.getAttribute("class");

        if (fieldname === "" || !fieldname || el.type === "hidden") return;

        // Handle different field types
        // Check box data type
        if (el.type === "checkbox") {
          data[fieldname] = el.checked;
        // Date and Date time data type
        } else if (el.type === "text" && fieldname.indexOf('_datepicker_description') > 0 && classname.indexOf('money') < 0) {
          if (el.value) {
            data[fieldname.replace('_datepicker_description','')] = new Date(el.value).toISOString();
          }
        // Lookup data type - [fieldid]@odata.bind: /tableschemas(guid)
        } else if (el.type === "text" && fieldname.indexOf('_name') > 0 && classname.indexOf('money') < 0) {
          let tableIdSchemaName = fieldname.replace('_name','');
          if (tableIdSchemaName) {
            data[tableIdSchemaName + '@odata.bind'] = '/' + document.getElementById(tableIdSchemaName + '_entityname').value + 's(' + document.getElementById(tableIdSchemaName).value + ')';
          }
        // Currency data type 
        } else if (el.type === "text" && classname.indexOf('money') > 0) {
            data[fieldname] = parseFloat(el.value.replace(/,/g, ''));
        // Check box rendered as radio button data type
        } else if (el.type === "radio") {
          if (fieldname.indexOf('_0') > 0 && el.checked) {
            data[fieldname.replace('_0','')] = false;
          }
          if (fieldname.indexOf('_1') > 0 && el.checked) {
            data[fieldname.replace('_1','')] = true;
          }
        // Option set data type
        } else if (el.tagName.toLowerCase() === "select") {
          // Option sets: Dataverse expects integer values
          if (el.value) {
            data[fieldname] = parseInt(el.value);
          }
        // Default: Text, number, email, other data types
        } else {
          if (el.value) {
            data[fieldname] = el.value;
          }
        }
      });
    });

    // If submitRecord is set to true then update Status Reason
    if (submitRecord === true) {
      data["statuscode"] = submittedStatusReasonValue;
      data["ins_submitteddate"] = new Date();
    }

    return data;
  },

  /**
   * saveRecord: PATCH a Dataverse row via Portals Web API.
   * @param {string} entityLogicalName - e.g., "ins_applications"
   * @param {string} recordId - GUID (with or without braces)
   * @param {object} data - JSON fields to update
   * @returns {Promise}
   */
  saveRecord: function(entityLogicalName, recordId, data) {
    
    let _url = recordId
    ? "/_api/" + entityLogicalName + "(" + recordId + ")"
    : "/_api/" + entityLogicalName

    let httpRequestType = recordId ? "PATCH" : "POST"

    return webapi.safeAjax({
        type: httpRequestType,
        url: _url,
        async: false,
        contentType: "application/json",
        data: JSON.stringify(data),

        // SUCCESS CALLBACK
        success: function (res, status, xhr) {
            // This function runs if the API call returns a success status (e.g., 201 Created)
            const entityId = xhr.getResponseHeader("entityid");
            console.log("Record saved successfully!");
        },

        // ERROR CALLBACK
        error: function (xhr, textStatus, errorThrown) {
            // This function runs if the API call fails (e.g., 404 Not Found, 400 Bad Request, 403 Forbidden)
            console.error("An error occurred during the Web API call.");
            console.error("Status:", textStatus);
            console.error("Error Thrown:", errorThrown);

            // Attempt to get a specific error message from the Dataverse response
            if (xhr.responseJSON && xhr.responseJSON.error && xhr.responseJSON.error.message) {
                alert("Error: " + xhr.responseJSON.error.message);
            } else {
                alert("An unexpected error occurred. Check the console for details.");
            }
        }
    });
  },

  openEwayModalAsync: function(cfg) {
    return new Promise((resolve, reject) => {
      try {
        eCrypt.showModalPayment(cfg, function (result, transactionID, errors) {
          const status = (result || '').toLowerCase();
          if (status === 'complete') return resolve({ transactionID: transactionID, cancelled: false, errorMessage: null });
          if (status === 'cancel') return resolve({ transactionID: null, cancelled: true, errorMessage: null });
          if (status === 'error' || result?.Errors) return reject({ transactionID: null, cancelled: false, errorMessage: errors });
        });
      } catch (error) {
        reject({ transactionID: null, cancelled: false, errorMessage: error });
      }
    });
  },

  // Lock Process Payment button, change label and set isSubmitting to true
  lockPayButton: function(btnProcessPaymentID, isSubmitting) {
    isSubmitting.value = true; // modifies the original object
    const $btn = $('#' + btnProcessPaymentID);
    $btn.prop('disabled', true).addClass('disabled').attr('aria-disabled', 'true');
    $btn.text('Processing...')
  },

  // Unlock Process Payment button, change label back to normal and set isSubmitting to false
  unlockPayButton: function(btnProcessPaymentID, isSubmitting) {
    const $btn = $('#' + btnProcessPaymentID);
    $btn.prop('disabled', false).removeClass('disabled').removeAttr('aria-disabled');
    $btn.text($btn.attr('aria-label'));
    isSubmitting.value = false; // modifies the original object
  },

  convertSelectToAutocomplete: function(selectName, selectPlaceholder) {
    selectPlaceholder = selectPlaceholder ?? "";
    var selectElement = $("#" + selectName);
    var selectElementClass = selectElement.attr("class");
    var readonly = $(selectElement).attr("readonly") ?? "";
    var autoCompleteElementId = selectName + "-autocomplete";
    var autoCompleteDatasetId = selectName + "-data";
    var autoCompleteElement = '<input name="' + autoCompleteElementId + '" id="' + autoCompleteElementId + '" class="' + selectElementClass + '" list="' + autoCompleteDatasetId + '" placeholder="' + selectPlaceholder + '" ' + readonly + '><datalist id="' + selectName + '-data"></datalist>';
    var options = "";

    $(selectElement).parent().append(autoCompleteElement);
    $("#" + selectName + " option").each(function (index, o) {
        options += '<option data-value="' + o.value + '" value="' + o.text + '"/>';
    });
    $("#" + autoCompleteDatasetId).html(options);

    $(selectElement).hide();

    var currentSelectedValue = $(selectElement).val();
    if (!!currentSelectedValue) {
        $("#" + autoCompleteElementId).val($(selectElement).find("option:selected").text());
    }

    $("#" + autoCompleteElementId).on("change", function () {
        var selectedValue = $("#" + autoCompleteDatasetId + " option[value='" + $("#" + autoCompleteElementId).val() + "']").attr("data-value");
        selectElement.val(selectedValue);
        if (typeof selectedValue === "undefined") {
            $("#" + autoCompleteElementId).val("");
            // optionally you can add an error message here
        };
    });
  },

  prePopulateLookup: function(fieldName, valueName, valueId, table)
  {
    $('#' + fieldName + '_name').val(valueName);
    $('#' + fieldName + '_name').attr('value', valueName);
    $('#' + fieldName).attr('value', valueId);
    $('#' + fieldName + '_entityname').attr('value',table);
  },

  getPortalUrl: function () {
    return window.location.origin;
  },

  setFieldInvalid($field) {
    const $tr = $field.closest("tr");
    const isRequired = $(".required", $tr).length > 0 ? "is-required" : "";
    const isMandatory = $(".mandatory-field", $tr).length > 0 ? "is-incomplete" : "";
    if ($tr.length > 0) {
      if ($field.val().trim().length === 0) {
        $tr.addClass(`${isRequired} ${isMandatory}`);
      } else {
        $tr.removeClass(`${isRequired} ${isMandatory}`);
      }
    }
  },
  
  // validate and get validatiors from forms
  manageValidators: function (form, formValidators, addFields, removeFields) {
    if (form && Array.isArray(formValidators)) {
      if (Array.isArray(addFields)) {
        formValidators = this.addValidators(form, formValidators, addFields);
      }
      if (Array.isArray(removeFields)) {
        formValidators = this.removeValidators(form, formValidators, removeFields);
      }
      return formValidators;
    }
    console.warn("Warning portal_common.manageValidators() - form cannot be null, formValidators must be an array");
    return [];
  },

  // Add validators from forms dynamically
  addValidators: function (form, formValidators, fieldNames, customErrorMessage) {
    const self = this;
    if (form && Array.isArray(formValidators) && Array.isArray(fieldNames)) {
      const newValidators = [];
      fieldNames.forEach((fieldName) => {
        // Check if field already exists in the list
        const exists = formValidators.filter((item) => {
          return item.id === `RequiredFieldValidator${fieldName}`;
        });
        if (exists.length === 0) {
          const $field = $(`#${fieldName}`, form);
          const $label = $(`#${fieldName}_label`, form);
          // Create new validator
          if ($field.length > 0 && $label.length > 0) {
            if (!$field.hasClass("mandatory-field")) {
              $field.addClass("mandatory-field");
            }
            $field.prop("required", true);
            $field.attr("aria-required", true);
            $(".info", $field.closest("td")).addClass("required");

            // Create new validator object
            var Requiredvalidator = document.createElement("span");
            Requiredvalidator.style.display = "none";
            Requiredvalidator.id = `RequiredFieldValidator${fieldName}`;
            Requiredvalidator.controltovalidate = fieldName;

            if (customErrorMessage !== null) {
              Requiredvalidator.errormessage = `<a href="#${fieldName}">` + customErrorMessage + `</a>`;
            }
            else {
              Requiredvalidator.errormessage = `<a href="#${fieldName}">${$label.html()} is a required field.</a>`;
            }

            Requiredvalidator.initialvalue = "";
            Requiredvalidator.evaluationfunction = function () {
              const isValid = $field.val().trim().length > 0;
              if (!isValid) {
                self.setFieldInvalid($field);
              }
              return isValid;
            };
            newValidators.push(Requiredvalidator);
          }
        }
      });
      return newValidators.concat(formValidators);
    }
    console.warn("Warning portal_common.addValidators() - form cannot be null, formValidators or fieldNames must be an array");
    return [];
  },

  // remove validators from forms dynamically
  removeValidators: function (form, formValidators, fieldNames) {
    if (form && Array.isArray(formValidators) && Array.isArray(fieldNames)) {
      fieldNames.forEach((fieldName) => {
        const $field = $(`#${fieldName}`, form);
        if ($field.length > 0) {
          if ($field.hasClass("mandatory-field")) {
            $field.removeClass("mandatory-field");
          }
          $field.prop("required", false);
          $field.removeAttr("aria-required");
          $(".info", $field.closest("td")).removeClass("required");
          $field.closest("tr").removeClass("is-touched is-incomplete is-required");

          const removeIndex = formValidators.findIndex((item) => {
            return item.id == `RequiredFieldValidator${fieldName}`;
          });
          formValidators.splice(removeIndex, 1);
        }
      });
      return formValidators;
    }
    console.warn("Warning portal_common.removeValidator() - form cannot be null, formValidators or fieldNames must be an array");
    return [];
  },

  isDevEnv: function () {
    return window.location.href.search("-dev") > 0;
  },

  errorMessage: function(message, show) {
    if (show)
    {
        $('#reg-error').show(500);
        $('#reg-error').html('<span class="fa fa-info-circle" aria-hidden="true"></span> ' + message);
        setTimeout("$('#reg-error').hide(500);",10000);
    }
    else
    {
        $('#reg-error').hide(500);
    }
  },

  setEnabled: function (fieldName, enabled) {
    $("#" + fieldName).prop('disabled', !enabled);
  },

  setVisible: function (fieldName, visible) {
    if (visible) {
      $("#" + fieldName).show();
    }
    else {
      $("#" + fieldName).hide();
    }
  },

  setRequired: function(fieldName, required) {
    $("#" + fieldName).prop('required', required);
    if (required) {
      $("#" + fieldName).closest(".control").prev().addClass("required");
    } else {
      $("#" + fieldName).closest(".control").prev().removeClass("required");
    }
  },

  setValue: function (fieldName, value) {
    $("#" + fieldName).val(value);
  },

  remove: function (fieldName) {
    $("#" + fieldName).remove();
  },

  loadingSpinnerShow: function() {
    if ($(".data-loading-spinner").length) {
      // if already there do nothing
    } else {
      // if not there inject div and change display
      $("body").prepend(
        "<div class='data-loading-spinner' style='display: none;'><i class='fa fa-spinner rotating'></i></div>"
      );
  
      $(".data-loading-spinner").prop("style", "display: block; z-index: 3;");
      $(".alt-bg").prop("style", "z-index: -10;");
    }
  },
  
  loadingSpinnerHide: function() {
    $(".data-loading-spinner").remove();
    $(".alt-bg").removeAttr("style");
  },

};

/**
 * Show a native Power Pages error message using portal_common.errorMessage
 * @param {string} message - The error message to display
 * @param {boolean} [isSticky=true] - Whether the message should be sticky
 */
portal_common.errorMessage = function(message, isSticky) {
  // Use Power Pages notification system if available
  if (typeof window.showNotification === "function") {
    window.showNotification(message, isSticky ? "error" : "info");
  } else {
    // Fallback: show alert if notification system is not available
    alert(message);
  }
};

// Example usage:
// portal_common.errorMessage('ER-01: Error saving data to Dataverse. Please contact admin.', true);

/* Portal Alert ///////////////////////////////////////////////////////////////////////
* How to use:
* Add content by using append or prepend
* Content can be string or HTML string
* alertMsg.show(type) - type can be one of 6 options
      alertMsg.types.SUCCESS
      alertMsg.types.DANGER
      alertMsg.types.WARNING
      alertMsg.types.INFO
      alertMsg.types.MESSAGE
      // Or custom
      {
        cssClass: "alert-custom-css",
        iconClass: "fa-circle-question",
      }

// Delcare the instance 
const alertMsg = new AlertMessage();

** EXAMPLE USAGE **
alertMsg.append('hello is there a problem 4?');
alertMsg.append('hello I take HTML <a href="#>Some link</a>');
alertMsg.prepend('hello is there a problem 1?');
alertMsg.show(alertMsg.types.SUCCESS); // check icon
alertMsg.show(alertMsg.types.DANGER);
alertMsg.show(alertMsg.types.WARNING);
alertMsg.show(alertMsg.types.INFO);
alertMsg.show(alertMsg.types.MESSAGE); // No icon
alertMsg.show();
alertMsg.scrollTo();
alertMsg.reset();
alertMsg.hide();

** Add the HTML to the template where the alert needs to be shown **
<div class="alert-container" portal-alert>
   <div class="alert" role="alert">
     <i aria-hidden="true" class="fa"></i>
     <div class="alert-content"></div>
     <button type="button" class="close" aria-label="Close">
       <span aria-hidden="true">&times;</span>
      </button>
   </div>
</div>
*/
portal_common.PortalAlert = function ($element) {
  const $el = $element === undefined ? $("[portal-alert]") : $element;
  if ($el) {
    this.init($el);
  } else {
    console.warn("Portal Alert - No <div portal-alert></div> html found");
  }
};
portal_common.PortalAlert.prototype = {
  init: function ($el) {
    this.types = {
      SUCCESS: { cssClass: "alert-success", iconClass: "fa-circle-check" },
      WARNING: {
        cssClass: "alert-warning",
        iconClass: "fa-exclamation-triangle",
      },
      DANGER: {
        cssClass: "alert-danger",
        iconClass: "fa-exclamation-triangle",
      },
      INFO: { cssClass: "alert-info", iconClass: "fa-circle-info" },
      MESSAGE: { cssClass: "alert-info", iconClass: "hide" },
    };

    this._offsetY = 20;
    this._msgList = [];
    this._alertClass = this.types.INFO.cssClass;
    this._iconClass = this.types.INFO.iconClass;
    this.$el = $el;
    this.msgHtml = "";
    this.$content = $(".alert-content", this.$el);
    this.$alert = $(".alert", this.$el);
    this.$icon = $(".fa", this.$el);
    this.$icon.hide();
    this.$close = $(".close", this.$el);
    this.$close.on("click", this.hide.bind(this));
  },

  append: function (msg) {
    var addMsg = this.add(msg);
    if (addMsg) {
      this.$content.append(addMsg);
    }
  },

  prepend: function (msg) {
    var addMsg = this.add(msg);
    if (addMsg) {
      this.$content.prepend(addMsg);
    }
  },

  add: function (msg) {
    if (typeof msg === "string") {
      if (!this._msgExists(msg)) {
        this._msgList.push(msg);
        if (this._isHTML(msg)) {
          return msg;
        }
        return (msg = "<p>" + msg + "</p>");
      }
    }
    return null;
  },

  show: function (type) {
    this._alertClass =
      type === undefined ? this.type.INFO.cssClass : type.cssClass;
    this._iconClass =
      type === undefined ? this.type.INFO.iconClass : type.iconClass;
    if (this.$content.children().length > 0) {
      this.$alert.removeClass(this._alertClass);
      //   this._alertClass = props.type;
      if (!this.$alert.hasClass(this._alertClass)) {
        this.$alert.addClass(this._alertClass);
      }

      this.$icon.removeClass(this._iconClass);
      //   this._iconClass = props.icon;
      if (!this.$icon.hasClass(this._iconClass)) {
        this.$icon.addClass(this._iconClass);
      }
      if (this._iconClass) {
        this.$icon.show();
      } else {
        this.$icon.hide();
      }

      if (!this.$el.hasClass("show")) {
        this.$el.addClass("show");
      }
    }
  },

  hide: function () {
    this.$el.removeClass("show");
    this.reset();
  },

  reset: function () {
    this._msgList = [];
    this.$content.empty();
  },

  scrollTo: function () {
    $([document.documentElement, document.body]).animate(
      {
        scrollTop: this.$alert.offset().top - this._offsetY,
      },
      1000
    );
  },

  hasAlerts: function () {
    if (this.$content) {
      return this.$content.children().length > 0;
    }
    return false;
  },

  _msgExists: function (msg) {
    var err = false;
    this._msgList.forEach(function (str) {
      var test = str.match(msg);
      if (Array.isArray(test)) {
        err = str.match(msg).length > 0;
      }
    });
    return err;
  },

  _isHTML: function (str) {
    var doc = new DOMParser().parseFromString(str, "text/html");
    return Array.from(doc.body.childNodes).some(function (node) {
      node.nodeType === 1;
    });
  },
};

/**
 * Create and manage cookies
 */
portal_common.setCookie = (name, value, days = 1) => {
  let expires = "";
  if (days) {
    var date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = "; expires=" + date.toUTCString();
  }
  document.cookie = name + "=" + (value || "") + expires + "; path=/";
};

portal_common.getCookie = (name) => {
  const nameEQ = name + "=";
  const ca = document.cookie.split(";");
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == " ") c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
};

portal_common.eraseCookie = (name) => {
  document.cookie = name + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
};

/** Portal Modal ///////////////////////////////////////////////
 * How to use:
 * HTML template has been placed in the EO-Footer

// Delcare the instance 
const portalModal = new PortalModal();

// Basic usage             
portalModal.show((modal) => {
      // This is the call back function
      if (modal.result === 'yes') {
          // Do something on user response
          console.log('callback', modal.data);
      }
},
      {
          // Title string only
          title: 'This is a custom modal',
          // Details can be a string or html
          content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ',
      }
);


// Advanced usage
portalModal.show((modal) => {
      // This is the call back function
      if (modal.result === 'yes') {
          // Do something on user response
          console.log('callback', modal.data);
      }
      if (modal.result === 'not-sure') {
          // Do something on user response
          console.log('callback - not sure what to do', modal.data);
      }
  },

      {
          // Title string only
          title: 'This is a custom modal',
          // Details can be a string or html
          content: '<strong>Lorem ipsum dolor sit amet</strong> consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et <a href="#">dolore magna aliqua.</a> ',
          // Custom buttons
          btns: [
              { value: '', label: 'Cancel', cssClass: 'btn-secondary btn-left' },
              { value: 'not-sure', label: 'Not sure?', cssClass: 'btn-warning' },
              { value: 'yes', label: 'Yes please!', cssClass: 'btn-primary' }
          ]
      },
      // Pass soome data through to the call back function
      { data: 'pass some data' }
);

*/

portal_common.PortalModal = function () {
  var self = this;
  var loaded = function () {
    var $el = $("[portal-modal]");
    if ($el.length > 0) {
      self.init($el);
    } else {
      console.warn("Portal Modal - No <div portal-modal></div> html found");
    }
  };
  if (document.readyState !== "complete") {
    document.addEventListener(
      "DOMContentLoaded",
      () => {
        loaded();
      },
      false
    );
  } else {
    loaded();
  }
};
portal_common.PortalModal.prototype = {
  init: function ($el) {
    this._data = null;
    this._$modal = $el;
    this._$title = $(".modal-title", this._$modal);
    this._$body = $(".modal-body", this._$modal);
    this._$footer = $(".modal-footer", this._$modal);
    this._callback = null;
    this.__onHide = this._onHide.bind(this);
    this.__onClick = this._onClick.bind(this);
    this._default = {
      title: "Warning!",
      content: "Choose an option",
      btns: [
        { label: "Cancel", value: null, cssClass: "btn-left" },
        { label: "Yes", value: "yes", cssClass: "btn-primary" },
      ],
    };
    this._content = this._default;
    this._ready = true;
    if (this._showWhenReady && this._props) {
      this.show(this._props.callback, this._props.data, this._props.props);
    }
    this._showWhenReady = false;
  },

  _config: function () {
    this._$title.html(this._content.title);
    this._$body.html(this._content.content);
    if (Array.isArray(this._content.btns)) {
      this._addButtons();
    }
  },

  _addButtons: function () {
    var self = this;
    this._$footer.children().remove();
    this._content.btns.forEach(function (btnContent) {
      var $btn = $(document.createElement("button"));
      $btn.prop("type", "button");
      $btn.data("value", btnContent.value);
      $btn.html(btnContent.label);
      $btn.addClass("btn");
      $btn.addClass(btnContent.cssClass);
      $btn.on("click", self.__onClick);
      self._$footer.append($btn);
    });
  },

  _onClick: function (e) {
    this._$modal.off("hidden.bs.modal", this.__onHide);
    this.hide();
    if (this._callback) {
      var val = $(e.target).data("value");
      this._callback({ result: val, data: this._data });
    }
  },

  _onHide: function () {
    this._$modal.off("hidden.bs.modal", this.__onHide);
    if (this._callback) {
      this._callback({ result: null, data: this._data });
    }
  },

  getDefaults: function () {
    return this._default;
  },

  show: function (callback, props, data) {
    if (this._ready) {
      this._val = null;
      this._data = data;
      this._callback = callback;
      this._content.title = props.title ? props.title : this._default.title;
      this._content.content = props.content
        ? props.content
        : this._default.content;
      this._content.btns = props.btns ? props.btns : this._default.btns;
      this._config();
      this._$modal.modal("show");
      this._$modal.on("hidden.bs.modal", this.__onHide);
      this.focus();
    } else {
      this._showWhenReady = true;
      this._props = {
        callback: callback,
        data: data,
        props: props,
      };
    }
  },

  hide: function () {
    if (this._ready) {
      this._$modal.modal("hide");
      this._$modal.off("hidden.bs.modal", this.__onHide);
    }
  },

  focus: function () {
    if (this._ready) {
      this._$modal.focus();
    }
  },

  getValue: function () {
    return this._val;
  },
};

/* Portal Spinner //////////////////////////////////////////////////////////
* How to use
* HTML Template is within the Footer.html
// Declare the instance
const portalSpinner = new PortalSpinner();
// Show and hide
portalSpinner.show();
portalSpinner.hide();
*/
portal_common.PortalSpinner = function () {
  var self = this;
  var loaded = function () {
    console.log("loaded", this._showWhenReady);
    var $el = $("[portal-spinner]");
    if ($el.length > 0) {
      self.init($el);
    }
  };
  if (
    document.readyState !== "complete" &&
    document.readyState !== "interactive"
  ) {
    document.addEventListener("DOMContentLoaded", () => {
      loaded();
    });
  } else {
    loaded();
  }
};
portal_common.PortalSpinner.prototype = {
  init: function ($el) {
    this._props;
    this._isOpen = false;
    this.__hideComplete = (e) => this._hideComplete(e);
    this._$el = $el;
    this._$text = $(".portal-spinner-text", this._$el);
    this._ready = true;
    this._focusRestrict();
    if (this._showWhenReady) {
      this.show(this._props);
    }
    this._showWhenReady = false;
  },

  show: function (props) {
    this._props = props;
    console.log("ready", this._ready);
    if (this._ready) {
      if (!this._isOpen) {
        this._isOpen = true;
        if (props && props.blur) {
          $(document.body).addClass("blur-content");
        }
        $(document.html).addClass("no-scroll");
        this._lastFocus = document.activeElement;
        this._$el.attr("tabindex", 0);
        this._$el[0].focus();
        this._$el.fadeIn();
        this._$el.addClass("is-active");
      }
    } else {
      this._showWhenReady = true;
    }
  },

  hide: function () {
    this._isOpen = false;
    if (this._ready) {
      this._$el.fadeOut(this.__hideComplete);
      if (this._lastFocus) {
        this._lastFocus.focus();
      }
      if ($(document.body).hasClass("blur-content")) {
        $(document.body).removeClass("blur-content");
      }
    }
  },

  _hideComplete: function () {
    $(document.html).removeClass("no-scroll");
    this._$el.removeClass("is-active");
  },

  _focusRestrict: function (e) {
    document.addEventListener(
      "focus",
      function (e) {
        if (this._isOpen && !$el[0].contains(e.target)) {
          e.stopPropagation();
          $el[0].focus();
        }
      },
      true
    );
  },
};

// $(function () {
//   console.log("jquery & bootstrap are ready");
// });

/**
 * Accessible language menu toggle for ART Portal header
 * (Power Pages portal common JS best practice: IIFE, no globals, event delegation)
 */
(function () {
  function setupLangMenu(menuSelector, btnSelector) {
    const menu = document.querySelector(menuSelector);
    const btn = document.querySelector(btnSelector);
    if (!menu || !btn) return;

    function toggleMenu() {
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!expanded));
      if (!expanded) {
        menu.removeAttribute('hidden');
        menu.focus && menu.focus();
      } else {
        menu.setAttribute('hidden', '');
      }
    }

    function closeMenu() {
      btn.setAttribute('aria-expanded', 'false');
      menu.setAttribute('hidden', '');
    }

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      toggleMenu();
    });

    document.addEventListener('click', function (e) {
      if (!btn.contains(e.target) && !menu.contains(e.target)) {
        closeMenu();
      }
    });

    btn.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeMenu();
      if ((e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') && menu.hasAttribute('hidden')) {
        e.preventDefault();
        toggleMenu();
        menu.querySelector('li')?.focus();
      }
    });

    menu.querySelectorAll('li').forEach(function (li) {
      li.setAttribute('tabindex', '0');
      li.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeMenu();
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          (li.nextElementSibling || menu.firstElementChild).focus();
        }
        if (e.key === 'ArrowUp') {
          e.preventDefault();
          (li.previousElementSibling || menu.lastElementChild).focus();
        }
        if (e.key === 'Enter' || e.key === ' ') {
          li.click();
        }
      });
      li.addEventListener('click', function () {
        // Set language here if needed
        closeMenu();
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    setupLangMenu('.ART-header-lang-menu .ART-header-lang-list', '#ARTLangBtn');
    setupLangMenu('.navbar-nav .ART-header-lang-list', '#ARTLangBtnMobile');
  });
})();
